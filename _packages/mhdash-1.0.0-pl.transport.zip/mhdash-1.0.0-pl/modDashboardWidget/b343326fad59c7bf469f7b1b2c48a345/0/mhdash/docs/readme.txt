mhDash is a simple RSS feed widget that displays data from my own MODX Blog located at http://www.markhamstra.com/modx-blog/. It allows you to see all the latests posts straight from your MODX Manager.

The code behind this Extra has been mostly scraped off the MODX News Feed Dashboard widget - with some real minor changes.
