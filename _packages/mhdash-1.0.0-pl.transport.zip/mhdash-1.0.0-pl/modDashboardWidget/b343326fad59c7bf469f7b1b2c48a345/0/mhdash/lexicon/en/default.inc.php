<?php

$_lang['mhdash.title'] = 'Mark Hamstra\'s MODX Blog';
$_lang['mhdash.description'] = 'Never miss a post on Mark Hamstra\'s MODX Blog! This Dashboard widget will show you the latest entries on the blog - right in your MODX Manager.';
$_lang['mhdash.feedunavailable'] = 'Uh oh - it looks like Mark\'s latest articles can not be shown at this point.';
