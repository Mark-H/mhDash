<?php

$_lang['mhdash.title'] = 'Mark Hamstra\'s MODX Blog';
$_lang['mhdash.description'] = 'Mis geen post meer op Mark Hamstra\'s MODX Blog! Door middel van dit dashboard widget blijf je altijd op de hoogte.';
$_lang['mhdash.feedunavailable'] = 'Uh oh - het ziet er naar uit dat Mark\'s laatste berichten niet kunnen worden getoond.';
